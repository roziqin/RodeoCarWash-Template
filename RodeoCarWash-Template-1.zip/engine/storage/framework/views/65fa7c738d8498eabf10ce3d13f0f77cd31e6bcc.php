<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Laravel Project</title>

<link rel="stylesheet" type="text/css" href="css/app.css">
<link rel="stylesheet" type="text/css" href="css/style.css"><?php /**PATH D:\xampp-7.3.8\htdocs\laravel-project\engine\resources\views/Partials/head.blade.php ENDPATH**/ ?>