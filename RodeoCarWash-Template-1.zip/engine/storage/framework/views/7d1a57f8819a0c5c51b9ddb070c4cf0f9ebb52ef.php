<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Laravel Project</title>

<link rel="stylesheet" type="text/css" href="css/app.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('engine/node_modules/mdbootstrap/css/mdb.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('engine/node_modules/mdbootstrap/css/modules/animations-extended.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="css/compiled-4.8.8.min.css?new3">
<link rel="stylesheet" type="text/css" href="css/style.css?new5">
<?php /**PATH D:\xampp-7.3.8\htdocs\RodeoCarWash-Template\engine\resources\views/Partials/head.blade.php ENDPATH**/ ?>