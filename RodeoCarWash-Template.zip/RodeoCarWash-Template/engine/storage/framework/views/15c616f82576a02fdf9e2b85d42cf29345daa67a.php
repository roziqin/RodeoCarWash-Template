<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('Partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-12 p-2">
                    <a href="<?php echo e(url('/')); ?>" class="float-left pl-3 pr-3"><img src="images/arrow-left.png" height="32"></a>
                </div>
                <div class="col-12 pt-3 pb-5">
                    <h1 class="text-center">SILAHKAN PILIH MERK KENDARAAN ANDA</h1>
                </div>
            </div>
            <div class="row">
                <?php
                for ($i=0; $i < 18 ; $i++) { 
                ?>
                    <div class="col-3 col-md-2 mb-4 list-item">
                        <a href="<?php echo e(url('tipe')); ?>">
                            <img src="images/logo.png">
                            <div class="info-item">
                                <h5 class="text-center p-1">Nama Merk</h5>
                            </div>
                        </a>
                    </div>
                <?php
                }

                ?>
            </div>
        </div>
        <?php echo $__env->make('Partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\xampp-7.3.8\htdocs\laravel-project\engine\resources\views/merk.blade.php ENDPATH**/ ?>